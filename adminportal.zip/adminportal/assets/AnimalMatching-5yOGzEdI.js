const a="/adminportal/assets/AnimalMatching-C0F6cc2p.jpg";export{a as default};
