const a="/adminportal/assets/ShadowMatching-CMnm4CqC.jpg";export{a as default};
