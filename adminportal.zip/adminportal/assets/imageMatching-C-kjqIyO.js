const a="/adminportal/assets/imageMatching-COCqWFlF.jpg";export{a as default};
