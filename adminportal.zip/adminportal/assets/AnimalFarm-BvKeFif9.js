const a="/adminportal/assets/AnimalFarm-DrXLQUqq.jpg";export{a as default};
