const a="/adminportal/assets/DragAndMatch-B4JJKTTs.jpg";export{a as default};
