const a="/adminportal/assets/JoiningShapes-CmSLVNBN.jpg";export{a as default};
