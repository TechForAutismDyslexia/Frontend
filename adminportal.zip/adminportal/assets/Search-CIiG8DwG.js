const a="/adminportal/assets/Search-D_OlXQc2.jpg";export{a as default};
