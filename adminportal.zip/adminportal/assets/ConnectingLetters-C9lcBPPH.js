const t="/adminportal/assets/ConnectingLetters-DSt0E5kg.jpg";export{t as default};
