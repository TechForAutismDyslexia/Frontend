const a="/adminportal/assets/tabledraganddrop-C0uZnHVJ.jpg";export{a as default};
