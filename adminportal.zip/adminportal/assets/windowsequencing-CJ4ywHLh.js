const n="/adminportal/assets/windowsequencing-DAmgQZ9K.jpg";export{n as default};
