const e="/adminportal/assets/SentenceVerification1-CrDu6_kn.jpg";export{e as default};
