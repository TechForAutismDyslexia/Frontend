const s="/adminportal/assets/MissingLetter-BlNbYJ1l.jpg";export{s as default};
