const e="/adminportal/assets/Shape-Design-Bwdd7T1e.jpg";export{e as default};
