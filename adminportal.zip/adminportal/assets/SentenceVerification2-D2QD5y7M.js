const e="/adminportal/assets/SentenceVerification2-A57Hlh3o.jpg";export{e as default};
